# 🏢 GESTIONE STUDIO - CONSULTING GROUP SRL

## 📊 **STATO ATTUALE DEL PROGETTO** 
**Versione**: 2.0 - Sistema Completo DatiUtenza  
**Data**: 04 Agosto 2025  
**Build**: Operativo e Funzionante ✅

---

## 🎯 **DESCRIZIONE GENERALE**

Sistema di gestione completo per studio professionale con sistema di autorizzazione a 3 livelli e gestione avanzata di dati sensibili (password, PIN, credenziali).

### 🔐 **CARATTERISTICHE PRINCIPALI:**
- ✅ **Sistema Multi-Ruolo**: Administrator, UserSenior, User
- ✅ **Permessi Granulari**: Accesso personalizzato per singolo utente
- ✅ **8 Sezioni Dati Utenza**: Banche, Carte, Utenze, Mail, Entratel, Cancelleria, PC, Altri
- ✅ **Password Sempre Visibili**: Nessun toggle, visualizzazione diretta
- ✅ **Sicurezza Avanzata**: [Bind] attributes, validazione modelli
- ✅ **Dashboard Personalizzate**: Per ogni ruolo utente
- ✅ **Build DLL**: Pronto per hosting IIS esterno

---

## 🔧 **CONFIGURAZIONE SISTEMA**

### 🗄️ **Database**: 
- **Server**: `IT15\SQLEXPRESS`
- **Database**: `Consulting`
- **Connection String**: Configurata in `appsettings.json`

### 🌐 **Web Server**:
- **URL Locale**: http://localhost:5000
- **Framework**: ASP.NET Core 8.0 MVC
- **Hosting**: IIS Ready (DLL + web.config)

### 👥 **Utenti di Test**:
```
Administrator: admin/123456    (accesso completo + gestione sistema)
UserSenior:    senior/123456   (accesso avanzato reports)  
User:          user/123456     (accesso limitato base)
User:          fede/123456     (accesso personalizzato)
```

---

## 🏗️ **ARCHITETTURA APPLICAZIONE**

### 📁 **Struttura Progetto**:
```
ConsultingGroup/
├── Controllers/           # Logica business
│   ├── DatiUtenzaController.cs      # Banche, Carte, Utenze, Mail, Entratel
│   ├── DatiUtenzaExtraController.cs # Cancelleria, PC, AltriDati  
│   ├── UserPermissionsController.cs # Gestione permessi
│   ├── AccountController.cs         # Autenticazione
│   ├── AdminController.cs           # Funzioni amministrative
│   ├── UserController.cs            # Dashboard user
│   ├── SeniorController.cs          # Dashboard senior
│   └── GestioneClientiController.cs # Gestione clienti
├── Models/               # Entità dati
│   ├── ApplicationUser.cs          # Utente esteso
│   ├── UserPermissions.cs          # Permessi granulari
│   ├── Banche.cs                   # Dati bancari
│   ├── CarteCredito.cs             # Carte di credito
│   ├── Utenze.cs                   # Utenze servizi
│   ├── Mail.cs                     # Account email
│   ├── Entratel.cs                 # Dati fiscali
│   ├── Cancelleria.cs              # Fornitori cancelleria
│   ├── UtentiPC.cs                 # Credenziali PC
│   └── AltriDati.cs                # Dati generici
├── Views/                # Interfaccia utente  
│   ├── DatiUtenza/                 # Views sezioni principali
│   ├── DatiUtenzaExtra/            # Views sezioni ausiliarie
│   ├── UserPermissions/            # Views gestione permessi
│   └── Shared/                     # Layout e componenti
├── Services/             # Logica business
│   ├── UserPermissionsService.cs   # Servizi permessi
│   └── DatabaseSeeder.cs           # Inizializzazione DB
├── Attributes/           # Custom attributes
│   └── UserPermissionAttribute.cs  # Controllo accesso granulare
├── ViewModels/           # DTOs per le view
│   ├── DatiUtenzaViewModel.cs      # Dashboard dati utenza
│   └── UserPermissionsViewModel.cs # Gestione permessi UI
└── Data/                 # Context database
    └── ApplicationDbContext.cs     # EF Core context
```

---

## 🔐 **SISTEMA AUTORIZZAZIONE**

### 👑 **Administrator (Accesso Completo)**:
- ✅ Gestione Permessi Utenti
- ✅ Impostazioni Sistema  
- ✅ Creazione/Modifica Utenti
- ✅ Tutte le Sezioni Dati Utenza
- ✅ Reports Avanzati

### 👔 **UserSenior (Accesso Avanzato)**:
- ✅ Gestione Clienti (se autorizzato)
- ✅ Dati Utenza (se autorizzato)
- ✅ Reports Avanzati (se autorizzato)
- ❌ Impostazioni Sistema
- ❌ Gestione Utenti

### 👤 **User (Accesso Base + Personalizzato)**:
- ✅ Gestione Clienti (se autorizzato)
- ✅ Dati Utenza (se autorizzato)  
- ✅ Visualizzazione Dati Base (se autorizzato)
- ❌ Reports Avanzati (salvo autorizzazione)
- ❌ Area Riservata (salvo autorizzazione)

### 🎛️ **Permessi Granulari Disponibili**:
```csharp
- CanAccessGestioneClienti      # Gestione clienti
- CanAccessDatiUtenza          # Sezioni dati sensibili
- CanAccessReports             # Reports base
- CanAccessViewBasicData       # Visualizzazione dati base
- CanAccessAdvancedReports     # Reports avanzati
- CanAccessRestrictedArea      # Area riservata
- CanViewStatisticsInDashboard # Statistiche dashboard
- CanViewPersonalReports       # Reports personali
- CanViewActivityHistory       # Cronologia attività
- CanViewAdminData             # Dati amministrativi
```

---

## 🗃️ **SEZIONI DATI UTENZA** (Password Sempre Visibili)

### 🏦 **1. BANCHE** `/DatiUtenza/Banche`
**Gestione**: DatiUtenzaController  
**Campi**: Nome Banca, IBAN, Codice Utente, **Password**, Indirizzo, Note  
**Status**: ✅ Operativo (2 record di test)

### 💳 **2. CARTE DI CREDITO** `/DatiUtenza/CarteCredito`
**Gestione**: DatiUtenzaController  
**Campi**: Numero Carta, Intestazione, Scadenza, **PIN**, Note  
**Status**: ✅ Operativo (2 record di test)

### ⚡ **3. UTENZE** `/DatiUtenza/Utenze`
**Gestione**: DatiUtenzaController  
**Campi**: Denominazione, Sito Web, Nome Utente, **Password**, Note  
**Status**: ✅ Operativo (pronto per dati)

### 📧 **4. MAIL** `/DatiUtenza/Mail`
**Gestione**: DatiUtenzaController  
**Campi**: Indirizzo Mail, Nome Utente, **Password**, Note  
**Status**: ✅ Operativo (pronto per dati)

### 📄 **5. ENTRATEL** `/DatiUtenza/Entratel`
**Gestione**: DatiUtenzaController  
**Campi**: Sito, Utente, **Password**, **PIN Catastali**, **PIN Deleghe**, **PIN Completo**, Desktop Telematico (User/**Pass**), Note  
**Status**: ✅ Operativo (pronto per dati)

### 🏪 **6. CANCELLERIA** `/DatiUtenzaExtra/Cancelleria`
**Gestione**: DatiUtenzaExtraController  
**Campi**: Denominazione Fornitore, Sito Web, Nome Utente, **Password**, Note  
**Status**: ✅ Operativo (pronto per dati)

### 💻 **7. UTENTI PC** `/DatiUtenzaExtra/UtentiPC`
**Gestione**: DatiUtenzaExtraController  
**Campi**: Nome PC, Utente, **Password**, Indirizzo Rete, Note  
**Status**: ✅ Operativo (pronto per dati)

### 📁 **8. ALTRI DATI** `/DatiUtenzaExtra/AltriDati`
**Gestione**: DatiUtenzaExtraController  
**Campi**: Nome, Sito Web, Utente, **Password**, Note  
**Status**: ✅ Operativo (pronto per dati)

---

## 🔍 **FUNZIONALITÀ IMPLEMENTATE**

### ✅ **Sistema Autenticazione**:
- Login/Logout con ASP.NET Core Identity
- Gestione sessioni utente
- Reset password
- Blocco account dopo tentativi falliti

### ✅ **Gestione Permessi**:
- Controller `UserPermissionsController` per Admin
- Servizio `UserPermissionsService` per logica business
- Attribute `UserPermissionAttribute` per controllo accesso
- ViewComponent `UserPermissions` per menu dinamico

### ✅ **Dashboard Personalizzate**:
- Dashboard Admin con gestione completa
- Dashboard Senior con funzioni avanzate  
- Dashboard User con accesso controllato
- Menu dinamico basato su permessi utente

### ✅ **Gestione Dati Sensibili**:
- **Password/PIN sempre visibili** (no toggle)
- Validazione robusta sui modelli
- [Bind] attributes per sicurezza contro over-posting
- Associazione automatica utente-dati

### ✅ **Database Management**:
- Entity Framework Core con migrazioni
- Seeding automatico utenti e ruoli di test
- Backup automatico database e codice
- 8 tabelle per dati utenza completamente configurate

---

## 🚀 **COME AVVIARE IL PROGETTO**

### 1️⃣ **Prerequisiti**:
```
- .NET 8.0 SDK
- SQL Server Express (IT15\SQLEXPRESS)
- Visual Studio/VS Code
```

### 2️⃣ **Setup Database**:
```bash
dotnet ef database update
```

### 3️⃣ **Avvio Applicazione**:
```bash
dotnet run --urls "http://localhost:5000"
```

### 4️⃣ **Login Test**:
```
http://localhost:5000
Username: admin | Password: 123456
```

---

## 🎯 **URLS PRINCIPALI DISPONIBILI**

### 🏠 **Dashboard**:
```
/                            # Homepage
/Admin                       # Dashboard Administrator  
/Senior                      # Dashboard UserSenior
/User                        # Dashboard User
```

### 🔐 **Gestione Utenti** (Admin Only):
```
/UserPermissions             # Gestione permessi granulari
/UserPermissions/Edit/{id}   # Modifica permessi utente
/Account/Register            # Registrazione nuovi utenti
```

### 🏦 **Dati Utenza - Sezioni Principali**:
```
/DatiUtenza                  # Dashboard generale dati utenza
/DatiUtenza/Banche           # ✅ Gestione conti bancari
/DatiUtenza/CarteCredito     # ✅ Gestione carte di credito  
/DatiUtenza/Utenze           # ✅ Gestione utenze servizi
/DatiUtenza/Mail             # ✅ Gestione account email
/DatiUtenza/Entratel         # ✅ Gestione accessi fiscali
```

### 🏪 **Dati Utenza - Sezioni Extra**:
```
/DatiUtenzaExtra/Cancelleria # ✅ Fornitori cancelleria
/DatiUtenzaExtra/UtentiPC    # ✅ Credenziali PC
/DatiUtenzaExtra/AltriDati   # ✅ Dati generici
```

### 👥 **Gestione Clienti**:
```
/GestioneClienti             # ✅ Gestione clienti (se autorizzato)
```

---

## 💾 **BACKUP E RESTORE**

### 📦 **Backup Disponibili** (cartella `/backups`):
- **Database**: `Consulting_20250804_130637.bak` (5.6MB)  
- **Codice**: `ConsultingGroup_Source_20250804_130728.zip` (97KB)
- **Script**: `create_backup.ps1` (automazione backup)
- **Docs**: `README_BACKUP.md` (istruzioni restore)

### 🔄 **Restore Database**:
```sql
RESTORE DATABASE [Consulting] 
FROM DISK = 'C:\dev\prova\backups\Consulting_YYYYMMDD_HHMMSS.bak' 
WITH REPLACE;
```

### 📁 **Restore Codice**:
```powershell
Expand-Archive -Path "backups\ConsultingGroup_Source_*.zip" -DestinationPath "restored\"
```

---

## 🔧 **CONFIGURAZIONI TECNICHE**

### ⚙️ **Configurazione Build**:
```xml
<UseAppHost>false</UseAppHost>        <!-- Solo DLL, no EXE -->
<OutputType>Exe</OutputType>          <!-- Compatible con top-level statements -->
```

### 🌐 **Configurazione IIS**:
```xml
<!-- web.config -->
<aspNetCore processPath="dotnet" 
            arguments=".\ConsultingGroup.dll" 
            hostingModel="InProcess" />
```

### 🔗 **Middleware Pipeline**:
```csharp
app.UseForwardedHeaders();     // Per hosting esterno  
app.UseAuthentication();       // Autenticazione ASP.NET Identity
app.UseAuthorization();        // Autorizzazione + permessi custom
```

---

## 🎨 **UI/UX FEATURES**

### 🎯 **Design Consistente**:
- ✅ Bootstrap 5 + Font Awesome icons
- ✅ Sidebar responsiva con menu dinamico
- ✅ Card-based layout per tutte le sezioni
- ✅ Colori distintivi per ogni sezione
- ✅ Tooltip per note lunghe

### 🔐 **Visualizzazione Password**:
- ✅ **Password sempre visibili** in `text-danger font-monospace`
- ✅ **PIN sempre visibili** in `text-danger font-monospace`
- ✅ **Nessun toggle/nascondimento** - visualizzazione diretta
- ✅ Form con `type="text"` per tutti i campi sensibili

### 📱 **Responsive Design**:
- ✅ Layout ottimizzato mobile/tablet/desktop
- ✅ Tabelle responsive con scroll orizzontale
- ✅ Form multi-colonna su desktop, single su mobile

---

## 🐛 **PROBLEMI RISOLTI**

### ✅ **Validazione Modelli**:
**Problema**: Errori validazione su `UserId` e navigation properties  
**Soluzione**: Rimosso `[Required]` da `UserId`, reso `User` nullable, aggiunto `[Bind]` attributes

### ✅ **Menu Dinamico**:
**Problema**: Menu duplicati e permessi non applicati  
**Soluzione**: ViewComponent `UserPermissions` per rendering dinamico

### ✅ **Build per IIS**:
**Problema**: Generazione EXE invece di DLL  
**Soluzione**: `UseAppHost=false` + middleware `ForwardedHeaders`

### ✅ **Password Toggle**:
**Problema**: JavaScript toggle complesso e inconsistente  
**Soluzione**: Rimosso completamente, password sempre visibili

---

## 🚀 **ROADMAP SVILUPPI FUTURI**

### 🔮 **Possibili Implementazioni**:
- [ ] API REST per accesso mobile
- [ ] Export dati in Excel/PDF  
- [ ] Audit log per modifiche dati sensibili
- [ ] Criptografia avanzata password
- [ ] Integrazione Active Directory
- [ ] Dashboard analytics avanzate
- [ ] Sistema notifiche/alert
- [ ] Backup automatico schedulato

---

## 📞 **SUPPORTO TECNICO**

### 🏢 **Progetto**: GESTIONE STUDIO - CONSULTING GROUP SRL  
### 👨‍💻 **Sviluppo**: Sistemi ASP.NET Core MVC  
### 📅 **Ultimo Aggiornamento**: 04 Agosto 2025  
### ✅ **Status**: OPERATIVO E COMPLETO

---

## 📋 **LOGS TECNICI**

### 🔄 **Migrazioni Database Applicate**:
```
✅ 20241201_000000_InitialCreate
✅ 20241205_000000_AddUserPermissions  
✅ 20250104_000000_CreateDatiUtenzaTables
✅ 20250804_000000_AddDatiUtenzaCompleteSystem
```

### 📊 **Statistiche Attuali**:
```
📦 Tabelle Database: 18 (Identity + DatiUtenza + Custom)
🏗️ Controllers: 8 
📄 Models: 12
🖼️ Views: 45+
👥 Utenti Test: 4 (admin, senior, user, fede)
🔐 Permessi: 10 tipologie granulari
💾 Database Size: ~5.6MB
```

---

*🎯 Sistema completo e operativo per la gestione di studio professionale con controllo granulare accessi e gestione sicura dati sensibili.*