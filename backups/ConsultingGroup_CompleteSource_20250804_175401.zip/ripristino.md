# 🔄 **GUIDA COMPLETA RIPRISTINO BACKUP**
**CONSULTING GROUP SRL - Sistema Gestione Studio**

---

## 📦 **BACKUP DISPONIBILI**

### 📊 **Database Backup:**
- **File**: `Consulting_20250804_130637.bak`
- **Dimensione**: 5.6 MB
- **Posizione**: `C:\dev\prova\backups\`
- **Contenuto**: Database completo con tutte le 8 sezioni DatiUtenza

### 📁 **Codice Sorgente:**
- **File**: `ConsultingGroup_Source_20250804_130728.zip`
- **Dimensione**: 97 KB
- **Posizione**: `C:\dev\prova\backups\`
- **Contenuto**: Codice completo con password sempre visibili

---

## 🗄️ **RIPRISTINO DATABASE SQL**

### 🎯 **METODO 1: SQL Server Management Studio (SSMS)**
```
1. Aprire SSMS
2. Connettersi a: IT15\SQLEXPRESS
3. Click destro su "Databases" → "Restore Database..."
4. Selezionare "Device" → Sfoglia
5. Aggiungere: C:\dev\prova\backups\Consulting_20250804_130637.bak
6. Database destinazione: Consulting
7. Spuntare "Overwrite the existing database (WITH REPLACE)"
8. Click "OK"
```

### 🎯 **METODO 2: Comando PowerShell Diretto**
```powershell
sqlcmd -S "IT15\SQLEXPRESS" -E -Q "RESTORE DATABASE [Consulting] FROM DISK = 'C:\dev\prova\backups\Consulting_20250804_130637.bak' WITH REPLACE;" -d "master"
```

### 🎯 **METODO 3: Se Database in Uso**
```powershell
# Step 1: Chiudere connessioni
sqlcmd -S "IT15\SQLEXPRESS" -E -Q "ALTER DATABASE [Consulting] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;"

# Step 2: Ripristinare
sqlcmd -S "IT15\SQLEXPRESS" -E -Q "RESTORE DATABASE [Consulting] FROM DISK = 'C:\dev\prova\backups\Consulting_20250804_130637.bak' WITH REPLACE;"

# Step 3: Riaprire accesso
sqlcmd -S "IT15\SQLEXPRESS" -E -Q "ALTER DATABASE [Consulting] SET MULTI_USER;"
```

---

## 📁 **RIPRISTINO CODICE SORGENTE**

### 🎯 **METODO 1: Sovrascrittura Completa**
```powershell
# Backup situazione attuale
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
Rename-Item "C:\dev\prova" "C:\dev\prova_backup_$timestamp"

# Creare nuova cartella
New-Item -ItemType Directory -Path "C:\dev\prova" -Force

# Estrarre backup
Expand-Archive -Path "C:\dev\prova_backup_$timestamp\backups\ConsultingGroup_Source_20250804_130728.zip" -DestinationPath "C:\dev\prova" -Force

# Copiare file essenziali
Copy-Item "C:\dev\prova_backup_$timestamp\appsettings.json" "C:\dev\prova\" -Force
Copy-Item "C:\dev\prova_backup_$timestamp\backups" "C:\dev\prova\" -Recurse -Force
```

### 🎯 **METODO 2: Ripristino in Nuova Cartella**
```powershell
# Creare cartella di ripristino
New-Item -ItemType Directory -Path "C:\dev\prova_restored" -Force

# Estrarre tutto
Expand-Archive -Path "C:\dev\prova\backups\ConsultingGroup_Source_20250804_130728.zip" -DestinationPath "C:\dev\prova_restored" -Force

# Setup ambiente
cd C:\dev\prova_restored
dotnet restore
dotnet build
```

### 🎯 **METODO 3: Ripristino Selettivo**
```powershell
# Estrarre in cartella temporanea
New-Item -ItemType Directory -Path "C:\temp\restore" -Force
Expand-Archive -Path "C:\dev\prova\backups\ConsultingGroup_Source_20250804_130728.zip" -DestinationPath "C:\temp\restore" -Force

# Copiare file specifici
Copy-Item "C:\temp\restore\Controllers\*" "C:\dev\prova\Controllers\" -Recurse -Force
Copy-Item "C:\temp\restore\Models\*" "C:\dev\prova\Models\" -Recurse -Force
Copy-Item "C:\temp\restore\Views\*" "C:\dev\prova\Views\" -Recurse -Force

# Pulire temporanea
Remove-Item "C:\temp\restore" -Recurse -Force
```

---

## 🔄 **RIPRISTINO COMPLETO AUTOMATICO**

### 📋 **Script PowerShell Automatico:**
```powershell
# ==========================================
# SCRIPT RIPRISTINO COMPLETO
# ==========================================
param(
    [string]$BackupPath = "C:\dev\prova\backups",
    [string]$DatabaseBackup = "Consulting_20250804_130637.bak",
    [string]$SourceBackup = "ConsultingGroup_Source_20250804_130728.zip",
    [string]$RestorePath = "C:\dev\prova_restored"
)

Write-Host "🔄 Avvio ripristino completo..." -ForegroundColor Green

# RIPRISTINO DATABASE
Write-Host "📊 Ripristino database..." -ForegroundColor Yellow
try {
    $dbRestore = "RESTORE DATABASE [Consulting] FROM DISK = '$BackupPath\$DatabaseBackup' WITH REPLACE;"
    sqlcmd -S "IT15\SQLEXPRESS" -E -Q $dbRestore -d "master"
    Write-Host "✅ Database ripristinato" -ForegroundColor Green
} catch {
    Write-Host "❌ Errore database: $_" -ForegroundColor Red
    exit 1
}

# RIPRISTINO CODICE
Write-Host "📁 Ripristino codice..." -ForegroundColor Yellow
try {
    if (Test-Path $RestorePath) { Remove-Item $RestorePath -Recurse -Force }
    New-Item -ItemType Directory -Path $RestorePath -Force
    Expand-Archive -Path "$BackupPath\$SourceBackup" -DestinationPath $RestorePath -Force
    Write-Host "✅ Codice ripristinato in: $RestorePath" -ForegroundColor Green
} catch {
    Write-Host "❌ Errore codice: $_" -ForegroundColor Red
    exit 1
}

# SETUP AMBIENTE
Write-Host "⚙️ Setup ambiente..." -ForegroundColor Yellow
try {
    Set-Location $RestorePath
    dotnet restore
    dotnet build
    Write-Host "✅ Ambiente configurato" -ForegroundColor Green
} catch {
    Write-Host "❌ Errore setup: $_" -ForegroundColor Red
}

Write-Host "🎉 RIPRISTINO COMPLETATO!" -ForegroundColor Green
Write-Host "📍 Percorso: $RestorePath" -ForegroundColor Cyan
Write-Host "🚀 Avvio: dotnet run --urls http://localhost:5000" -ForegroundColor Cyan
```

### 💾 **Salva lo script come:** `ripristino_completo.ps1`
```powershell
# Per eseguire:
.\ripristino_completo.ps1
```

---

## ⚡ **COMANDI RAPIDI**

### 🚀 **Ripristino Express (1 Linea)**
```powershell
# Solo Database
sqlcmd -S "IT15\SQLEXPRESS" -E -Q "RESTORE DATABASE [Consulting] FROM DISK = 'C:\dev\prova\backups\Consulting_20250804_130637.bak' WITH REPLACE;"

# Solo Codice (nuova cartella)
Expand-Archive -Path "C:\dev\prova\backups\ConsultingGroup_Source_20250804_130728.zip" -DestinationPath "C:\restore" -Force && cd C:\restore && dotnet run --urls "http://localhost:5000"
```

### 🔍 **Verifica Rapida Post-Ripristino**
```powershell
# Verifica Database
sqlcmd -S "IT15\SQLEXPRESS" -d "Consulting" -E -Q "SELECT COUNT(*) AS TabelleUtenza FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME IN ('Banche','CarteCredito','Utenze','Mail','Entratel','Cancelleria','UtentiPC','AltriDati')"

# Verifica Build
dotnet build --configuration Release --verbosity minimal
```

---

## ⚠️ **PRECAUZIONI PRE-RIPRISTINO**

### 🛡️ **Backup Situazione Attuale**
```powershell
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"

# Backup DB corrente
sqlcmd -S "IT15\SQLEXPRESS" -E -Q "BACKUP DATABASE [Consulting] TO DISK = 'C:\dev\prova\backups\Consulting_PreRestore_$timestamp.bak' WITH FORMAT;"

# Backup codice corrente
Compress-Archive -Path "Controllers", "Models", "Views" -DestinationPath "backups\PreRestore_$timestamp.zip" -Force
```

### 🔍 **Verifiche Preliminari**
```powershell
# Spazio disco
Get-WmiObject -Class Win32_LogicalDisk | Select-Object DeviceID, @{Name="FreeSpace(GB)";Expression={[math]::Round($_.FreeSpace/1GB,2)}}

# SQL Server attivo
Get-Service | Where-Object {$_.Name -like "*SQL*"} | Select-Object Name, Status

# Connessione DB
sqlcmd -S "IT15\SQLEXPRESS" -E -Q "SELECT @@VERSION"
```

---

## 🔧 **RISOLUZIONE PROBLEMI**

### ❌ **Database Occupato**
```powershell
# Chiudere tutte le connessioni
sqlcmd -S "IT15\SQLEXPRESS" -E -Q "ALTER DATABASE [Consulting] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;"
# Riprovare ripristino
```

### ❌ **File Bloccati**
```powershell
# Terminare processi .NET
taskkill /F /IM dotnet.exe
# Riprovare
```

### ❌ **Errori Path**
```powershell
# Usare percorsi più corti
# Es: C:\restore\ invece di C:\dev\prova_restored\
```

### ❌ **Permessi Negati**
```
1. Eseguire PowerShell come Administrator
2. Verificare permessi cartelle
3. Disabilitare temporaneamente antivirus
```

---

## 📋 **CHECKLIST POST-RIPRISTINO**

### ✅ **Verifica Database**
- [ ] Database "Consulting" presente
- [ ] 8 tabelle DatiUtenza esistenti (Banche, CarteCredito, etc.)
- [ ] Dati di test presenti (2 banche, 2 carte)
- [ ] Utenti di test funzionanti

### ✅ **Verifica Codice**
- [ ] Progetto compila senza errori
- [ ] Tutte le view presenti
- [ ] Controllers aggiornati
- [ ] Password sempre visibili (no toggle)

### ✅ **Verifica Funzionamento**
- [ ] Login admin/123456 funziona
- [ ] Menu dinamico carica
- [ ] Sezioni DatiUtenza accessibili
- [ ] CRUD operations funzionanti

---

## 🎯 **SCENARIO DI RIPRISTINO TIPICI**

### 🔄 **Scenario 1: Aggiornamento Fallito**
```powershell
# Ripristino completo in nuova cartella
Expand-Archive -Path "C:\dev\prova\backups\ConsultingGroup_Source_20250804_130728.zip" -DestinationPath "C:\dev\prova_clean" -Force
sqlcmd -S "IT15\SQLEXPRESS" -E -Q "RESTORE DATABASE [Consulting] FROM DISK = 'C:\dev\prova\backups\Consulting_20250804_130637.bak' WITH REPLACE;"
cd C:\dev\prova_clean
dotnet run --urls "http://localhost:5000"
```

### 🔄 **Scenario 2: Corruzione File**
```powershell
# Ripristino selettivo solo file danneggiati
Expand-Archive -Path "C:\dev\prova\backups\ConsultingGroup_Source_20250804_130728.zip" -DestinationPath "C:\temp\fix" -Force
Copy-Item "C:\temp\fix\Controllers\DatiUtenzaController.cs" "C:\dev\prova\Controllers\" -Force
Copy-Item "C:\temp\fix\Views\DatiUtenza\*" "C:\dev\prova\Views\DatiUtenza\" -Recurse -Force
```

### 🔄 **Scenario 3: Migrazione Server**
```powershell
# 1. Nuovo server: installare .NET 8.0 SDK
# 2. Creare cartella progetto
# 3. Estrarre codice
# 4. Configurare connection string per nuovo SQL Server
# 5. Ripristinare database
# 6. Testare applicazione
```

---

## 📞 **CONTATTI EMERGENZA**

### 🏢 **Informazioni Progetto**
- **Nome**: CONSULTING GROUP SRL
- **Versione**: 2.0 - Sistema Completo DatiUtenza  
- **Framework**: ASP.NET Core 8.0 MVC
- **Database**: SQL Server Express

### 📱 **Test Funzionamento**
- **URL**: http://localhost:5000
- **Login Test**: admin/123456
- **Sezioni**: 8 DatiUtenza complete
- **Feature**: Password sempre visibili

---

## 🎉 **SUCCESSO RIPRISTINO**

### ✅ **Se tutto funziona:**
```
🎯 Sistema ripristinato correttamente!
📍 Applicazione: http://localhost:5000  
🔐 Login: admin/123456
📊 Database: Tutte le tabelle presenti
💻 Codice: Password sempre visibili
🚀 Status: OPERATIVO
```

### 🔄 **Passi successivi:**
1. Testare login con tutti gli utenti
2. Verificare inserimento dati nelle 8 sezioni
3. Controllare permessi granulari
4. Creare nuovo backup di sicurezza

---

*🛡️ Mantieni sempre questa guida insieme ai file di backup per ripristini futuri!*