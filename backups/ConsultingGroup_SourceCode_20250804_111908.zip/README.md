# GESTIONE STUDIO - CONSULTING GROUP SRL v2.0

Un sistema completo di gestione studio legale sviluppato in ASP.NET Core MVC con **sistema multi-ruolo** e gestione avanzata delle autorizzazioni.

## 🚀 Caratteristiche Principali v2.0

### 🔐 Sistema Multi-Ruolo Implementato
- **Administrator**: Accesso completo a tutto il sistema
- **UserSenior**: Accesso a gestione amministrativa, clienti e dati personali
- **User**: Accesso limitato a gestione clienti e dati personali

### 🛡️ Autenticazione e Sicurezza
- **Login sicuro** con validazione client e server
- **Sistema di autorizzazione granulare** basato sui ruoli
- **Hash delle password** con ASP.NET Core Identity
- **Protezione CSRF** su tutti i form
- **Session management** automatico

### 📊 Dashboard Multi-Livello
- **Gestione Utenti completa** (solo Administrator)
- **Gestione Clienti** (tutti i ruoli)
- **Dati Utenza** (profilo personale - tutti i ruoli)
- **Gestione Amministrativa** (Administrator e UserSenior)
- **Statistiche in tempo reale** differenziate per ruolo

### 🗄️ Gestione Database
- **Migrazioni automatiche** al primo avvio
- **Seed automatico** con tutti i ruoli
- **SQL Server Express** con Windows Authentication

## 🔑 Credenziali di Accesso

### Utente Amministratore Predefinito
- **URL**: http://localhost:8080
- **Username**: admin
- **Password**: 123456
- **Ruolo**: Administrator

## 🏗️ Architettura del Progetto v2.0

### Nuovi Controllers
```
ConsultingGroup/
├── Controllers/
│   ├── HomeController.cs          # Reindirizzamento basato su autenticazione
│   ├── AccountController.cs       # Login/Logout
│   ├── AdminController.cs         # Dashboard (tutti) + Gestione Amministrativa (Admin+Senior)
│   ├── UserManagementController.cs # CRUD utenti (solo Administrator)
│   ├── GestioneClientiController.cs # Gestione clienti (tutti i ruoli) ✨ NUOVO
│   └── DatiUtenzaController.cs    # Profilo personale (tutti i ruoli) ✨ NUOVO
```

### Nuove Views
```
├── Views/
│   ├── DatiUtenza/
│   │   └── Index.cshtml           # ✨ Gestione profilo personale
│   ├── GestioneClienti/
│   │   ├── Index.cshtml           # ✨ Dashboard clienti
│   │   └── Placeholder.cshtml     # ✨ Sezioni in sviluppo
│   └── Shared/
│       ├── _Layout.cshtml         # ✨ Menu laterale con autorizzazioni per ruolo
│       └── _Breadcrumb.cshtml     # ✨ Breadcrumb aggiornato
```

## 🎯 Funzionalità per Ruolo

### 👑 Administrator
- ✅ **Dashboard**: Statistiche complete
- ✅ **Gestione Utenti**: CRUD completo, assegnazione ruoli
- ✅ **Gestione Amministrativa**: Funzionalità avanzate
- ✅ **Gestione Clienti**: Accesso completo
- ✅ **Dati Utenza**: Modifica profilo personale

### 🏆 UserSenior  
- ✅ **Dashboard**: Statistiche limitate
- ❌ **Gestione Utenti**: Non accessibile
- ✅ **Gestione Amministrativa**: Accesso completo
- ✅ **Gestione Clienti**: Accesso completo
- ✅ **Dati Utenza**: Modifica profilo personale

### 👤 User
- ✅ **Dashboard**: Statistiche base
- ❌ **Gestione Utenti**: Non accessibile
- ❌ **Gestione Amministrativa**: Non accessibile
- ✅ **Gestione Clienti**: Accesso completo
- ✅ **Dati Utenza**: Modifica profilo personale

## 🔧 Nuove Funzionalità v2.0

### 📝 Dati Utenza (Tutti i Ruoli)
- **Modifica profilo personale**: Nome, cognome, email
- **Cambio password**: Opzionale, con conferma
- **Visualizzazione informazioni account**: Ruolo, stato, date
- **Sicurezza**: Username non modificabile

### 🏢 Gestione Clienti (Tutti i Ruoli)
- **Dashboard clienti**: Statistiche e azioni rapide
- **Placeholder funzionalità**:
  - Lista clienti
  - Nuovo cliente
  - Ricerca avanzata
  - Report (futuro)

### 🎛️ Sistema Autorizzazioni
- **Menu dinamico**: Voci mostrate in base al ruolo
- **Controller protection**: Autorizzazioni granulari
- **Breadcrumb intelligente**: Navigazione contestuale

## 🛠️ Configurazione e Avvio

### Prerequisiti
- .NET 8.0 SDK
- SQL Server Express (IT15\SQLEXPRESS)
- Windows Authentication configurata

### Installazione Rapida
```bash
# 1. Termina eventuali processi attivi
taskkill /F /IM ConsultingGroup.exe

# 2. Naviga nella directory
cd C:\dev\prova

# 3. Build e avvio
dotnet build
dotnet run
```

### Primo Accesso
- **URL**: http://localhost:8080
- **Username**: admin
- **Password**: 123456
- **Ruolo**: Administrator

## 🗃️ Database v2.0

### Configurazione
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=IT15\\SQLEXPRESS;Database=Consulting;Trusted_Connection=true;TrustServerCertificate=true;MultipleActiveResultSets=true"
  }
}
```

### Ruoli Automatici
Il sistema crea automaticamente:
1. **Administrator**: Accesso completo
2. **UserSenior**: Accesso avanzato (nuovo) ✨
3. **User**: Accesso base

### Seeding Automatico
- ✅ Creazione database se non esiste
- ✅ Applicazione migrazioni automatiche
- ✅ Creazione tutti i ruoli
- ✅ Utente admin predefinito

## 🎨 UI/UX v2.0

### Menu Laterale Intelligente
- **Mostra solo le sezioni accessibili** per ogni ruolo
- **Icone differenziate** per tipo di contenuto
- **Badges ruolo** per identificazione visiva

### Nuove Pagine
- **Dati Utenza**: Form responsive per modifica profilo
- **Gestione Clienti**: Dashboard con statistiche e azioni
- **Placeholder moderne**: Design consistente per sezioni future

### Miglioramenti Design
- **Breadcrumb contestuali**: Navigazione migliorata
- **Badge ruolo**: Identificazione visiva immediata
- **Layout responsivo**: Ottimizzato per tutti i dispositivi

## 🔐 Sicurezza v2.0

### Autorizzazioni Granulari
```csharp
// Solo Administrator
[Authorize(Roles = "Administrator")]

// Administrator e UserSenior
[Authorize(Roles = "Administrator,UserSenior")]

// Tutti i ruoli autenticati
[Authorize(Roles = "Administrator,UserSenior,User")]
```

### Protezioni Implementate
- **Controller-level**: Protezione per intere sezioni
- **Action-level**: Controllo granulare per singole azioni
- **View-level**: Menu e contenuti basati sui ruoli
- **Database-level**: Prevenzione accessi non autorizzati

## 🚀 Deployment v2.0

### Sviluppo
```bash
dotnet run
# Accessibile su http://localhost:8080
```

### Test Multi-Ruolo
1. **Login come admin** (admin/123456)
2. **Crea utenti con ruoli diversi** da Gestione Utenti
3. **Testa autorizzazioni** con login differenti

## 🔮 Roadmap v3.0

### Prossimi Sviluppi
- [ ] **CRUD Clienti completo**: Implementazione database clienti
- [ ] **Gestione Amministrativa**: Funzionalità specifiche
- [ ] **Dashboard avanzate**: Grafici e report
- [ ] **Sistema notifiche**: Alert in tempo reale
- [ ] **Audit log**: Tracciamento azioni per ruolo

### Miglioramenti Pianificati
- [ ] **Role hierarchy**: Ereditarietà permessi
- [ ] **Permission fine-grained**: Controllo granulare
- [ ] **User groups**: Gruppi di utenti
- [ ] **Multi-tenant**: Supporto più studi

## 📋 Note di Rilascio v2.0

### ✨ Nuove Funzionalità
- Sistema multi-ruolo completo (Administrator, UserSenior, User)
- Pagina Dati Utenza per gestione profilo personale
- Sezione Gestione Clienti accessibile a tutti i ruoli
- Menu laterale dinamico basato sulle autorizzazioni
- Autorizzazioni granulari per controller e azioni

### 🔧 Miglioramenti
- DatabaseSeeder aggiornato con nuovo ruolo UserSenior
- Layout responsive ottimizzato per tutti i ruoli
- Breadcrumb navigation contestualizzati
- Sistema di messaggi migliorato

### 🛡️ Sicurezza
- Autorizzazioni differenziate per ogni ruolo
- Protezione delle sezioni amministrative
- Validazione profilo utente migliorata

## 🐛 Troubleshooting v2.0

### Errori Comuni
1. **File lock durante build**: `taskkill /F /IM ConsultingGroup.exe`
2. **Ruoli non visibili**: Verificare ApplicationDbContext migrato
3. **Menu non aggiornato**: Clear browser cache
4. **Autorizzazioni**: Verificare ruolo utente nel database

### Comandi Utilità
```bash
# Terminare processo
taskkill /F /IM ConsultingGroup.exe

# Reset completo database
dotnet ef database drop
dotnet ef database update

# Verifica ruoli
dotnet ef migrations list
```

---

## 📊 Stato Progetto

**Versione**: 2.0.0  
**Sistema Multi-Ruolo**: ✅ Implementato  
**Livello Completamento**: 85%  
**Data Aggiornamento**: Gennaio 2025  

### ✅ Completato
- Sistema di autenticazione e autorizzazione multi-ruolo
- Gestione profilo personale (Dati Utenza)
- Dashboard Gestione Clienti
- Menu dinamico basato sui ruoli
- Sicurezza granulare implementata

### 🔄 In Sviluppo
- CRUD completo per gestione clienti
- Funzionalità gestione amministrativa
- Sistema di report e statistiche avanzate

**🌐 L'applicazione è accessibile su http://localhost:8080**  
**🔑 Login: admin/123456 per accesso completo**  
**🚀 Pronta per sviluppi futuri e test multi-ruolo!**