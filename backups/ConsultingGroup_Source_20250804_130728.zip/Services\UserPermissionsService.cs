using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using ConsultingGroup.Data;
using ConsultingGroup.Models;

namespace ConsultingGroup.Services
{
    public interface IUserPermissionsService
    {
        Task<UserPermissions?> GetUserPermissionsAsync(string userId);
        Task<bool> UserCanAccessAsync(string userId, string permission);
        Task<UserPermissions> GetOrCreateUserPermissionsAsync(string userId);
    }

    public class UserPermissionsService : IUserPermissionsService
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public UserPermissionsService(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public async Task<UserPermissions?> GetUserPermissionsAsync(string userId)
        {
            return await _context.UserPermissions
                .FirstOrDefaultAsync(p => p.UserId == userId);
        }

        public async Task<bool> UserCanAccessAsync(string userId, string permission)
        {
            var userPermissions = await GetUserPermissionsAsync(userId);
            if (userPermissions == null)
            {
                return false;
            }

            return permission.ToLower() switch
            {
                "gestioneclienti" => userPermissions.CanAccessGestioneClienti,
                "datiutenza" => userPermissions.CanAccessDatiUtenza,
                "reports" => userPermissions.CanAccessReports,
                "viewbasicdata" => userPermissions.CanAccessViewBasicData,
                "advancedreports" => userPermissions.CanAccessAdvancedReports,
                "restrictedarea" => userPermissions.CanAccessRestrictedArea,
                "statisticsindashboard" => userPermissions.CanViewStatisticsInDashboard,
                "personalreports" => userPermissions.CanViewPersonalReports,
                "activityhistory" => userPermissions.CanViewActivityHistory,
                "admindata" => userPermissions.CanViewAdminData,
                _ => false
            };
        }

        public async Task<UserPermissions> GetOrCreateUserPermissionsAsync(string userId)
        {
            var permissions = await GetUserPermissionsAsync(userId);
            if (permissions != null)
            {
                return permissions;
            }

            // Crea permessi di default basati sul ruolo
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                throw new ArgumentException("Utente non trovato", nameof(userId));
            }

            var roles = await _userManager.GetRolesAsync(user);
            var primaryRole = roles.FirstOrDefault() ?? "";

            permissions = new UserPermissions
            {
                UserId = userId,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
                ModifiedBy = "System"
            };

            if (primaryRole == "UserSenior")
            {
                permissions.CanAccessGestioneClienti = true;
                permissions.CanAccessDatiUtenza = true;
                permissions.CanAccessReports = true;
                permissions.CanAccessViewBasicData = true;
                permissions.CanAccessAdvancedReports = true;
                permissions.CanAccessRestrictedArea = true;
                permissions.CanViewStatisticsInDashboard = true;
                permissions.CanViewPersonalReports = true;
                permissions.CanViewActivityHistory = true;
                permissions.CanViewAdminData = false;
            }
            else if (primaryRole == "User")
            {
                permissions.CanAccessGestioneClienti = true;
                permissions.CanAccessDatiUtenza = false;
                permissions.CanAccessReports = false;
                permissions.CanAccessViewBasicData = true;
                permissions.CanAccessAdvancedReports = false;
                permissions.CanAccessRestrictedArea = false;
                permissions.CanViewStatisticsInDashboard = true;
                permissions.CanViewPersonalReports = true;
                permissions.CanViewActivityHistory = true;
                permissions.CanViewAdminData = false;
            }
            else
            {
                // Administrator - non dovrebbe essere gestito da questo servizio
                // ma se succede, diamo tutti i permessi
                permissions.CanAccessGestioneClienti = true;
                permissions.CanAccessDatiUtenza = true;
                permissions.CanAccessReports = true;
                permissions.CanAccessViewBasicData = true;
                permissions.CanAccessAdvancedReports = true;
                permissions.CanAccessRestrictedArea = true;
                permissions.CanViewStatisticsInDashboard = true;
                permissions.CanViewPersonalReports = true;
                permissions.CanViewActivityHistory = true;
                permissions.CanViewAdminData = true;
            }

            _context.UserPermissions.Add(permissions);
            await _context.SaveChangesAsync();

            return permissions;
        }
    }
}