using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ConsultingGroup.Models;
using ConsultingGroup.Attributes;
using ConsultingGroup.Data;

namespace ConsultingGroup.Controllers
{
    [Authorize]
    [UserPermission("datiutenza")]
    public class DatiUtenzaExtraController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ILogger<DatiUtenzaExtraController> _logger;

        public DatiUtenzaExtraController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            ILogger<DatiUtenzaExtraController> logger)
        {
            _context = context;
            _userManager = userManager;
            _logger = logger;
        }

        #region Cancelleria
        public async Task<IActionResult> Cancelleria()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var cancelleria = await _context.Cancelleria.Where(c => c.UserId == user.Id).ToListAsync();
            return View(cancelleria);
        }

        public IActionResult CreateCancelleria()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateCancelleria([Bind("DenominazioneFornitore,SitoWeb,NomeUtente,Password,Note")] Cancelleria model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            if (ModelState.IsValid)
            {
                model.UserId = user.Id;
                model.CreatedAt = DateTime.UtcNow;
                model.UpdatedAt = DateTime.UtcNow;

                _context.Cancelleria.Add(model);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Fornitore cancelleria aggiunto con successo.";
                return RedirectToAction(nameof(Cancelleria));
            }

            return View(model);
        }

        public async Task<IActionResult> EditCancelleria(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var cancelleria = await _context.Cancelleria.FirstOrDefaultAsync(c => c.Id == id && c.UserId == user.Id);
            if (cancelleria == null) return NotFound();

            return View(cancelleria);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditCancelleria(int id, [Bind("Id,DenominazioneFornitore,SitoWeb,NomeUtente,Password,Note")] Cancelleria model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            if (id != model.Id) return NotFound();

            var cancelleria = await _context.Cancelleria.FirstOrDefaultAsync(c => c.Id == id && c.UserId == user.Id);
            if (cancelleria == null) return NotFound();

            if (ModelState.IsValid)
            {
                cancelleria.DenominazioneFornitore = model.DenominazioneFornitore;
                cancelleria.SitoWeb = model.SitoWeb;
                cancelleria.NomeUtente = model.NomeUtente;
                cancelleria.Password = model.Password;
                cancelleria.Note = model.Note;
                cancelleria.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Fornitore cancelleria aggiornato con successo.";
                return RedirectToAction(nameof(Cancelleria));
            }

            return View(model);
        }

        public async Task<IActionResult> DeleteCancelleria(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var cancelleria = await _context.Cancelleria.FirstOrDefaultAsync(c => c.Id == id && c.UserId == user.Id);
            if (cancelleria == null) return NotFound();

            _context.Cancelleria.Remove(cancelleria);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Fornitore cancelleria eliminato con successo.";
            return RedirectToAction(nameof(Cancelleria));
        }
        #endregion

        #region UtentiPC
        public async Task<IActionResult> UtentiPC()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var utentiPC = await _context.UtentiPC.Where(u => u.UserId == user.Id).ToListAsync();
            return View(utentiPC);
        }

        public IActionResult CreateUtentePC()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateUtentePC([Bind("NomePC,Utente,Password,IndirizzoRete,Note")] UtentiPC model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            if (ModelState.IsValid)
            {
                model.UserId = user.Id;
                model.CreatedAt = DateTime.UtcNow;
                model.UpdatedAt = DateTime.UtcNow;

                _context.UtentiPC.Add(model);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Utente PC aggiunto con successo.";
                return RedirectToAction(nameof(UtentiPC));
            }

            return View(model);
        }

        public async Task<IActionResult> EditUtentePC(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var utentePC = await _context.UtentiPC.FirstOrDefaultAsync(u => u.Id == id && u.UserId == user.Id);
            if (utentePC == null) return NotFound();

            return View(utentePC);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditUtentePC(int id, [Bind("Id,NomePC,Utente,Password,IndirizzoRete,Note")] UtentiPC model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            if (id != model.Id) return NotFound();

            var utentePC = await _context.UtentiPC.FirstOrDefaultAsync(u => u.Id == id && u.UserId == user.Id);
            if (utentePC == null) return NotFound();

            if (ModelState.IsValid)
            {
                utentePC.NomePC = model.NomePC;
                utentePC.Utente = model.Utente;
                utentePC.Password = model.Password;
                utentePC.IndirizzoRete = model.IndirizzoRete;
                utentePC.Note = model.Note;
                utentePC.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Utente PC aggiornato con successo.";
                return RedirectToAction(nameof(UtentiPC));
            }

            return View(model);
        }

        public async Task<IActionResult> DeleteUtentePC(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var utentePC = await _context.UtentiPC.FirstOrDefaultAsync(u => u.Id == id && u.UserId == user.Id);
            if (utentePC == null) return NotFound();

            _context.UtentiPC.Remove(utentePC);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Utente PC eliminato con successo.";
            return RedirectToAction(nameof(UtentiPC));
        }
        #endregion

        #region AltriDati
        public async Task<IActionResult> AltriDati()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var altriDati = await _context.AltriDati.Where(a => a.UserId == user.Id).ToListAsync();
            return View(altriDati);
        }

        public IActionResult CreateAltriDati()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateAltriDati([Bind("Nome,SitoWeb,Utente,Password,Note")] AltriDati model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            if (ModelState.IsValid)
            {
                model.UserId = user.Id;
                model.CreatedAt = DateTime.UtcNow;
                model.UpdatedAt = DateTime.UtcNow;

                _context.AltriDati.Add(model);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Altri dati aggiunti con successo.";
                return RedirectToAction(nameof(AltriDati));
            }

            return View(model);
        }

        public async Task<IActionResult> EditAltriDati(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var altriDati = await _context.AltriDati.FirstOrDefaultAsync(a => a.Id == id && a.UserId == user.Id);
            if (altriDati == null) return NotFound();

            return View(altriDati);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditAltriDati(int id, [Bind("Id,Nome,SitoWeb,Utente,Password,Note")] AltriDati model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            if (id != model.Id) return NotFound();

            var altriDati = await _context.AltriDati.FirstOrDefaultAsync(a => a.Id == id && a.UserId == user.Id);
            if (altriDati == null) return NotFound();

            if (ModelState.IsValid)
            {
                altriDati.Nome = model.Nome;
                altriDati.SitoWeb = model.SitoWeb;
                altriDati.Utente = model.Utente;
                altriDati.Password = model.Password;
                altriDati.Note = model.Note;
                altriDati.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Altri dati aggiornati con successo.";
                return RedirectToAction(nameof(AltriDati));
            }

            return View(model);
        }

        public async Task<IActionResult> DeleteAltriDati(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var altriDati = await _context.AltriDati.FirstOrDefaultAsync(a => a.Id == id && a.UserId == user.Id);
            if (altriDati == null) return NotFound();

            _context.AltriDati.Remove(altriDati);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Altri dati eliminati con successo.";
            return RedirectToAction(nameof(AltriDati));
        }
        #endregion
    }
}