using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ConsultingGroup.Models
{
    public class UserPermissions
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string UserId { get; set; } = string.Empty;

        [ForeignKey("UserId")]
        public virtual ApplicationUser User { get; set; } = null!;

        // Permessi per le sezioni principali
        public bool CanAccessGestioneClienti { get; set; } = true;
        public bool CanAccessDatiUtenza { get; set; } = false;
        public bool CanAccessReports { get; set; } = false;
        public bool CanAccessViewBasicData { get; set; } = true;
        public bool CanAccessAdvancedReports { get; set; } = false;
        public bool CanAccessRestrictedArea { get; set; } = false;

        // Permessi specifici nelle pagine
        public bool CanViewStatisticsInDashboard { get; set; } = true;
        public bool CanViewPersonalReports { get; set; } = true;
        public bool CanViewActivityHistory { get; set; } = true;
        public bool CanViewAdminData { get; set; } = false;

        // Metadati
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public string ModifiedBy { get; set; } = string.Empty;
    }
}