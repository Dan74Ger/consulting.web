using ConsultingGroup.Models;

namespace ConsultingGroup.ViewModels
{
    public class UserPermissionsViewModel
    {
        public string UserId { get; set; } = string.Empty;
        public string UserName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        
        // Permessi per le sezioni principali
        public bool CanAccessGestioneClienti { get; set; } = true;
        public bool CanAccessDatiUtenza { get; set; } = false;
        public bool CanAccessReports { get; set; } = false;
        public bool CanAccessViewBasicData { get; set; } = true;
        public bool CanAccessAdvancedReports { get; set; } = false;
        public bool CanAccessRestrictedArea { get; set; } = false;

        // Permessi specifici nelle pagine
        public bool CanViewStatisticsInDashboard { get; set; } = true;
        public bool CanViewPersonalReports { get; set; } = true;
        public bool CanViewActivityHistory { get; set; } = true;
        public bool CanViewAdminData { get; set; } = false;

        public DateTime LastModified { get; set; }
        public string ModifiedBy { get; set; } = string.Empty;

        public static UserPermissionsViewModel FromUserPermissions(UserPermissions permissions, ApplicationUser user, string role)
        {
            return new UserPermissionsViewModel
            {
                UserId = user.Id,
                UserName = user.UserName ?? "",
                Email = user.Email ?? "",
                Role = role,
                FullName = user.FullName,
                CanAccessGestioneClienti = permissions.CanAccessGestioneClienti,
                CanAccessDatiUtenza = permissions.CanAccessDatiUtenza,
                CanAccessReports = permissions.CanAccessReports,
                CanAccessViewBasicData = permissions.CanAccessViewBasicData,
                CanAccessAdvancedReports = permissions.CanAccessAdvancedReports,
                CanAccessRestrictedArea = permissions.CanAccessRestrictedArea,
                CanViewStatisticsInDashboard = permissions.CanViewStatisticsInDashboard,
                CanViewPersonalReports = permissions.CanViewPersonalReports,
                CanViewActivityHistory = permissions.CanViewActivityHistory,
                CanViewAdminData = permissions.CanViewAdminData,
                LastModified = permissions.UpdatedAt,
                ModifiedBy = permissions.ModifiedBy
            };
        }
    }

    public class UserPermissionsListViewModel
    {
        public List<UserPermissionsViewModel> Users { get; set; } = new();
        public string SearchRole { get; set; } = string.Empty;
        public string SearchName { get; set; } = string.Empty;
    }
}