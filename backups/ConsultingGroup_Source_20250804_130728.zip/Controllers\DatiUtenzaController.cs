using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ConsultingGroup.Models;
using ConsultingGroup.ViewModels;
using ConsultingGroup.Attributes;
using ConsultingGroup.Data;

namespace ConsultingGroup.Controllers
{
    [Authorize]
    [UserPermission("datiutenza")]
    public class DatiUtenzaController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ILogger<DatiUtenzaController> _logger;

        public DatiUtenzaController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            ILogger<DatiUtenzaController> logger)
        {
            _context = context;
            _userManager = userManager;
            _logger = logger;
        }

        // GET: DatiUtenza - Dashboard principale
        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var viewModel = new DatiUtenzaViewModel
            {
                UserId = user.Id,
                UserName = user.UserName!,
                FullName = user.FullName,
                Banche = await _context.Banche.Where(b => b.UserId == user.Id).ToListAsync(),
                CarteCredito = await _context.CarteCredito.Where(c => c.UserId == user.Id).ToListAsync(),
                Utenze = await _context.Utenze.Where(u => u.UserId == user.Id).ToListAsync(),
                Cancelleria = await _context.Cancelleria.Where(c => c.UserId == user.Id).ToListAsync(),
                Mail = await _context.Mail.Where(m => m.UserId == user.Id).ToListAsync(),
                UtentiPC = await _context.UtentiPC.Where(u => u.UserId == user.Id).ToListAsync(),
                AltriDati = await _context.AltriDati.Where(a => a.UserId == user.Id).ToListAsync(),
                Entratel = await _context.Entratel.Where(e => e.UserId == user.Id).ToListAsync()
            };

            return View(viewModel);
        }

        #region Banche
        public async Task<IActionResult> Banche()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var banche = await _context.Banche.Where(b => b.UserId == user.Id).ToListAsync();
            return View(banche);
        }

        public IActionResult CreateBanca()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateBanca([Bind("NomeBanca,IBAN,CodiceUtente,Password,Indirizzo,Note")] Banche model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            // Log per debugging
            _logger.LogInformation($"CreateBanca - NomeBanca: {model.NomeBanca}, IBAN: {model.IBAN}, CodiceUtente: {model.CodiceUtente}");
            
            if (!ModelState.IsValid)
            {
                // Log errori di validazione
                foreach (var error in ModelState)
                {
                    _logger.LogWarning($"Validation Error - Key: {error.Key}, Errors: {string.Join(", ", error.Value.Errors.Select(e => e.ErrorMessage))}");
                }
                return View(model);
            }

            try
            {
                model.UserId = user.Id;
                model.CreatedAt = DateTime.UtcNow;
                model.UpdatedAt = DateTime.UtcNow;

                _context.Banche.Add(model);
                await _context.SaveChangesAsync();

                _logger.LogInformation($"Banca salvata con successo - ID: {model.Id}");
                TempData["SuccessMessage"] = "Dati banca aggiunti con successo.";
                return RedirectToAction(nameof(Banche));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Errore durante il salvataggio della banca");
                ModelState.AddModelError("", "Errore durante il salvataggio. Riprova.");
                return View(model);
            }
        }

        public async Task<IActionResult> EditBanca(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var banca = await _context.Banche.FirstOrDefaultAsync(b => b.Id == id && b.UserId == user.Id);
            if (banca == null) return NotFound();

            return View(banca);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditBanca(int id, [Bind("Id,NomeBanca,IBAN,CodiceUtente,Password,Indirizzo,Note")] Banche model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            if (id != model.Id) return NotFound();

            var banca = await _context.Banche.FirstOrDefaultAsync(b => b.Id == id && b.UserId == user.Id);
            if (banca == null) return NotFound();

            if (ModelState.IsValid)
            {
                banca.NomeBanca = model.NomeBanca;
                banca.IBAN = model.IBAN;
                banca.CodiceUtente = model.CodiceUtente;
                banca.Password = model.Password;
                banca.Indirizzo = model.Indirizzo;
                banca.Note = model.Note;
                banca.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Dati banca aggiornati con successo.";
                return RedirectToAction(nameof(Banche));
            }

            return View(model);
        }

        public async Task<IActionResult> DeleteBanca(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var banca = await _context.Banche.FirstOrDefaultAsync(b => b.Id == id && b.UserId == user.Id);
            if (banca == null) return NotFound();

            _context.Banche.Remove(banca);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Dati banca eliminati con successo.";
            return RedirectToAction(nameof(Banche));
        }
        #endregion

        #region Carte di Credito
        public async Task<IActionResult> CarteCredito()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var carte = await _context.CarteCredito.Where(c => c.UserId == user.Id).ToListAsync();
            return View(carte);
        }

        public IActionResult CreateCarta()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateCarta([Bind("NumeroCarta,Intestazione,MeseScadenza,AnnoScadenza,PIN,Note")] CarteCredito model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            if (ModelState.IsValid)
            {
                model.UserId = user.Id;
                model.CreatedAt = DateTime.UtcNow;
                model.UpdatedAt = DateTime.UtcNow;

                _context.CarteCredito.Add(model);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Carta di credito aggiunta con successo.";
                return RedirectToAction(nameof(CarteCredito));
            }

            return View(model);
        }

        public async Task<IActionResult> EditCarta(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var carta = await _context.CarteCredito.FirstOrDefaultAsync(c => c.Id == id && c.UserId == user.Id);
            if (carta == null) return NotFound();

            return View(carta);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditCarta(int id, [Bind("Id,NumeroCarta,Intestazione,MeseScadenza,AnnoScadenza,PIN,Note")] CarteCredito model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            if (id != model.Id) return NotFound();

            var carta = await _context.CarteCredito.FirstOrDefaultAsync(c => c.Id == id && c.UserId == user.Id);
            if (carta == null) return NotFound();

            if (ModelState.IsValid)
            {
                carta.NumeroCarta = model.NumeroCarta;
                carta.Intestazione = model.Intestazione;
                carta.MeseScadenza = model.MeseScadenza;
                carta.AnnoScadenza = model.AnnoScadenza;
                carta.PIN = model.PIN;
                carta.Note = model.Note;
                carta.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Carta di credito aggiornata con successo.";
                return RedirectToAction(nameof(CarteCredito));
            }

            return View(model);
        }

        public async Task<IActionResult> DeleteCarta(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var carta = await _context.CarteCredito.FirstOrDefaultAsync(c => c.Id == id && c.UserId == user.Id);
            if (carta == null) return NotFound();

            _context.CarteCredito.Remove(carta);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Carta di credito eliminata con successo.";
            return RedirectToAction(nameof(CarteCredito));
        }
        #endregion

        #region Utenze
        public async Task<IActionResult> Utenze()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var utenze = await _context.Utenze.Where(u => u.UserId == user.Id).ToListAsync();
            return View(utenze);
        }

        public IActionResult CreateUtenza()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateUtenza([Bind("DenominazioneUtenza,SitoWeb,NomeUtente,Password,Note")] Utenze model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            if (ModelState.IsValid)
            {
                model.UserId = user.Id;
                model.CreatedAt = DateTime.UtcNow;
                model.UpdatedAt = DateTime.UtcNow;

                _context.Utenze.Add(model);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Utenza aggiunta con successo.";
                return RedirectToAction(nameof(Utenze));
            }

            return View(model);
        }

        public async Task<IActionResult> EditUtenza(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var utenza = await _context.Utenze.FirstOrDefaultAsync(u => u.Id == id && u.UserId == user.Id);
            if (utenza == null) return NotFound();

            return View(utenza);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditUtenza(int id, [Bind("Id,DenominazioneUtenza,SitoWeb,NomeUtente,Password,Note")] Utenze model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            if (id != model.Id) return NotFound();

            var utenza = await _context.Utenze.FirstOrDefaultAsync(u => u.Id == id && u.UserId == user.Id);
            if (utenza == null) return NotFound();

            if (ModelState.IsValid)
            {
                utenza.DenominazioneUtenza = model.DenominazioneUtenza;
                utenza.SitoWeb = model.SitoWeb;
                utenza.NomeUtente = model.NomeUtente;
                utenza.Password = model.Password;
                utenza.Note = model.Note;
                utenza.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Utenza aggiornata con successo.";
                return RedirectToAction(nameof(Utenze));
            }

            return View(model);
        }

        public async Task<IActionResult> DeleteUtenza(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var utenza = await _context.Utenze.FirstOrDefaultAsync(u => u.Id == id && u.UserId == user.Id);
            if (utenza == null) return NotFound();

            _context.Utenze.Remove(utenza);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Utenza eliminata con successo.";
            return RedirectToAction(nameof(Utenze));
        }
        #endregion

        #region Mail
        public async Task<IActionResult> Mail()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var mail = await _context.Mail.Where(m => m.UserId == user.Id).ToListAsync();
            return View(mail);
        }

        public IActionResult CreateMail()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateMail([Bind("IndirizzoMail,NomeUtente,Password,Note")] Mail model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            if (ModelState.IsValid)
            {
                model.UserId = user.Id;
                model.CreatedAt = DateTime.UtcNow;
                model.UpdatedAt = DateTime.UtcNow;

                _context.Mail.Add(model);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Account mail aggiunto con successo.";
                return RedirectToAction(nameof(Mail));
            }

            return View(model);
        }

        public async Task<IActionResult> EditMail(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var mail = await _context.Mail.FirstOrDefaultAsync(m => m.Id == id && m.UserId == user.Id);
            if (mail == null) return NotFound();

            return View(mail);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditMail(int id, [Bind("Id,IndirizzoMail,NomeUtente,Password,Note")] Mail model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            if (id != model.Id) return NotFound();

            var mail = await _context.Mail.FirstOrDefaultAsync(m => m.Id == id && m.UserId == user.Id);
            if (mail == null) return NotFound();

            if (ModelState.IsValid)
            {
                mail.IndirizzoMail = model.IndirizzoMail;
                mail.NomeUtente = model.NomeUtente;
                mail.Password = model.Password;
                mail.Note = model.Note;
                mail.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Account mail aggiornato con successo.";
                return RedirectToAction(nameof(Mail));
            }

            return View(model);
        }

        public async Task<IActionResult> DeleteMail(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var mail = await _context.Mail.FirstOrDefaultAsync(m => m.Id == id && m.UserId == user.Id);
            if (mail == null) return NotFound();

            _context.Mail.Remove(mail);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Account mail eliminato con successo.";
            return RedirectToAction(nameof(Mail));
        }
        #endregion

        #region Entratel
        public async Task<IActionResult> Entratel()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var entratel = await _context.Entratel.Where(e => e.UserId == user.Id).ToListAsync();
            return View(entratel);
        }

        public IActionResult CreateEntratel()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateEntratel([Bind("Sito,Utente,Password,PinDatiCatastali,PinDelegheCassettoFiscale,PinCompleto,DesktopTelematicoUtente,DesktopTelematicoPassword,Note")] Entratel model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            if (ModelState.IsValid)
            {
                model.UserId = user.Id;
                model.CreatedAt = DateTime.UtcNow;
                model.UpdatedAt = DateTime.UtcNow;

                _context.Entratel.Add(model);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Dati Entratel aggiunti con successo.";
                return RedirectToAction(nameof(Entratel));
            }

            return View(model);
        }

        public async Task<IActionResult> EditEntratel(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var entratel = await _context.Entratel.FirstOrDefaultAsync(e => e.Id == id && e.UserId == user.Id);
            if (entratel == null) return NotFound();

            return View(entratel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditEntratel(int id, [Bind("Id,Sito,Utente,Password,PinDatiCatastali,PinDelegheCassettoFiscale,PinCompleto,DesktopTelematicoUtente,DesktopTelematicoPassword,Note")] Entratel model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            if (id != model.Id) return NotFound();

            var entratel = await _context.Entratel.FirstOrDefaultAsync(e => e.Id == id && e.UserId == user.Id);
            if (entratel == null) return NotFound();

            if (ModelState.IsValid)
            {
                entratel.Sito = model.Sito;
                entratel.Utente = model.Utente;
                entratel.Password = model.Password;
                entratel.PinDatiCatastali = model.PinDatiCatastali;
                entratel.PinDelegheCassettoFiscale = model.PinDelegheCassettoFiscale;
                entratel.PinCompleto = model.PinCompleto;
                entratel.DesktopTelematicoUtente = model.DesktopTelematicoUtente;
                entratel.DesktopTelematicoPassword = model.DesktopTelematicoPassword;
                entratel.Note = model.Note;
                entratel.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Dati Entratel aggiornati con successo.";
                return RedirectToAction(nameof(Entratel));
            }

            return View(model);
        }

        public async Task<IActionResult> DeleteEntratel(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToAction("Login", "Account");

            var entratel = await _context.Entratel.FirstOrDefaultAsync(e => e.Id == id && e.UserId == user.Id);
            if (entratel == null) return NotFound();

            _context.Entratel.Remove(entratel);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Dati Entratel eliminati con successo.";
            return RedirectToAction(nameof(Entratel));
        }
        #endregion
    }
}