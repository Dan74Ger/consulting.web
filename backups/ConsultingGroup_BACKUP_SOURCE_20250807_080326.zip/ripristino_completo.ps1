# ==========================================
# SCRIPT RIPRISTINO COMPLETO
# CONSULTING GROUP SRL - Sistema Gestione Studio
# ==========================================

param(
    [string]$BackupPath = "C:\dev\prova\backups",
    [string]$DatabaseBackup = "Consulting_20250804_130637.bak",
    [string]$SourceBackup = "ConsultingGroup_Source_20250804_130728.zip",
    [string]$RestorePath = "C:\dev\prova_restored",
    [switch]$SkipDatabase,
    [switch]$SkipSource,
    [switch]$CreateBackupBefore
)

# Funzione per scrivere messaggi colorati
function Write-ColorOutput([String] $message, [String] $color = "White") {
    Write-Host $message -ForegroundColor $color
}

# Header
Clear-Host
Write-ColorOutput "======================================================" "Cyan"
Write-ColorOutput "🔄 RIPRISTINO COMPLETO - CONSULTING GROUP SRL" "Cyan"
Write-ColorOutput "======================================================" "Cyan"
Write-ColorOutput ""

# Verifica parametri
Write-ColorOutput "📋 CONFIGURAZIONE:" "Yellow"
Write-ColorOutput "   📁 Backup Path: $BackupPath" "Gray"
Write-ColorOutput "   🗄️ Database: $DatabaseBackup" "Gray"
Write-ColorOutput "   📦 Codice: $SourceBackup" "Gray"
Write-ColorOutput "   📍 Destinazione: $RestorePath" "Gray"
Write-ColorOutput ""

# Verifica esistenza file backup
if (!(Test-Path "$BackupPath\$DatabaseBackup")) {
    Write-ColorOutput "❌ ERRORE: File database backup non trovato!" "Red"
    Write-ColorOutput "   📍 Cercato: $BackupPath\$DatabaseBackup" "Gray"
    exit 1
}

if (!(Test-Path "$BackupPath\$SourceBackup")) {
    Write-ColorOutput "❌ ERRORE: File codice backup non trovato!" "Red"
    Write-ColorOutput "   📍 Cercato: $BackupPath\$SourceBackup" "Gray"
    exit 1
}

Write-ColorOutput "✅ File backup verificati" "Green"
Write-ColorOutput ""

# Backup preventivo se richiesto
if ($CreateBackupBefore) {
    Write-ColorOutput "🛡️ Creazione backup preventivo..." "Yellow"
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    
    try {
        # Backup database corrente
        $preBackupDB = "BACKUP DATABASE [Consulting] TO DISK = '$BackupPath\Consulting_PreRestore_$timestamp.bak' WITH FORMAT;"
        sqlcmd -S "IT15\SQLEXPRESS" -E -Q $preBackupDB -d "master" | Out-Null
        
        # Backup codice corrente (se esiste)
        if (Test-Path "C:\dev\prova\Controllers") {
            Compress-Archive -Path "C:\dev\prova\Controllers", "C:\dev\prova\Models", "C:\dev\prova\Views" -DestinationPath "$BackupPath\PreRestore_$timestamp.zip" -Force
        }
        
        Write-ColorOutput "✅ Backup preventivo creato: PreRestore_$timestamp" "Green"
    } catch {
        Write-ColorOutput "⚠️ Backup preventivo fallito: $_" "Yellow"
    }
    Write-ColorOutput ""
}

# RIPRISTINO DATABASE
if (!$SkipDatabase) {
    Write-ColorOutput "📊 RIPRISTINO DATABASE..." "Yellow"
    Write-ColorOutput "   🔌 Server: IT15\SQLEXPRESS" "Gray"
    Write-ColorOutput "   🗄️ Database: Consulting" "Gray"
    
    try {
        # Test connessione SQL Server
        $sqlTest = sqlcmd -S "IT15\SQLEXPRESS" -E -Q "SELECT @@VERSION" 2>&1
        if ($LASTEXITCODE -ne 0) {
            throw "Impossibile connettersi a SQL Server"
        }
        
        # Tentativo ripristino diretto
        $dbRestore = "RESTORE DATABASE [Consulting] FROM DISK = '$BackupPath\$DatabaseBackup' WITH REPLACE;"
        $result = sqlcmd -S "IT15\SQLEXPRESS" -E -Q $dbRestore -d "master" 2>&1
        
        if ($LASTEXITCODE -ne 0) {
            Write-ColorOutput "   ⚠️ Database in uso, chiusura connessioni..." "Yellow"
            
            # Chiudere connessioni attive
            sqlcmd -S "IT15\SQLEXPRESS" -E -Q "ALTER DATABASE [Consulting] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;" -d "master" | Out-Null
            
            # Riprovare ripristino
            sqlcmd -S "IT15\SQLEXPRESS" -E -Q $dbRestore -d "master" | Out-Null
            
            # Riaprire accesso multi-user
            sqlcmd -S "IT15\SQLEXPRESS" -E -Q "ALTER DATABASE [Consulting] SET MULTI_USER;" -d "master" | Out-Null
        }
        
        # Verifica ripristino
        $tableCount = sqlcmd -S "IT15\SQLEXPRESS" -d "Consulting" -E -Q "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME IN ('Banche','CarteCredito','Utenze','Mail','Entratel','Cancelleria','UtentiPC','AltriDati')" -h -1
        
        Write-ColorOutput "✅ Database ripristinato con successo" "Green"
        Write-ColorOutput "   📊 Tabelle DatiUtenza: $($tableCount.Trim())/8" "Gray"
        
    } catch {
        Write-ColorOutput "❌ Errore ripristino database: $_" "Red"
        Write-ColorOutput "   💡 Verifica che SQL Server sia in esecuzione" "Yellow"
        Write-ColorOutput "   💡 Verifica permessi su database" "Yellow"
        exit 1
    }
    Write-ColorOutput ""
} else {
    Write-ColorOutput "⏭️ Ripristino database saltato" "Gray"
    Write-ColorOutput ""
}

# RIPRISTINO CODICE SORGENTE
if (!$SkipSource) {
    Write-ColorOutput "📁 RIPRISTINO CODICE SORGENTE..." "Yellow"
    Write-ColorOutput "   📦 Estrazione: $SourceBackup" "Gray"
    Write-ColorOutput "   📍 Destinazione: $RestorePath" "Gray"
    
    try {
        # Rimuovere cartella esistente se presente
        if (Test-Path $RestorePath) {
            Write-ColorOutput "   🗑️ Rimozione cartella esistente..." "Gray"
            Remove-Item $RestorePath -Recurse -Force
        }
        
        # Creare cartella di destinazione
        New-Item -ItemType Directory -Path $RestorePath -Force | Out-Null
        
        # Estrarre backup
        Write-ColorOutput "   📦 Estrazione file..." "Gray"
        Expand-Archive -Path "$BackupPath\$SourceBackup" -DestinationPath $RestorePath -Force
        
        # Verifica estrazione
        $controllerCount = (Get-ChildItem "$RestorePath\Controllers" -Filter "*.cs" -ErrorAction SilentlyContinue).Count
        $modelCount = (Get-ChildItem "$RestorePath\Models" -Filter "*.cs" -ErrorAction SilentlyContinue).Count
        $viewDirs = (Get-ChildItem "$RestorePath\Views" -Directory -ErrorAction SilentlyContinue).Count
        
        Write-ColorOutput "✅ Codice sorgente ripristinato" "Green"
        Write-ColorOutput "   🎮 Controllers: $controllerCount" "Gray"
        Write-ColorOutput "   📊 Models: $modelCount" "Gray"
        Write-ColorOutput "   🖼️ View Directories: $viewDirs" "Gray"
        
    } catch {
        Write-ColorOutput "❌ Errore ripristino codice: $_" "Red"
        exit 1
    }
    Write-ColorOutput ""
} else {
    Write-ColorOutput "⏭️ Ripristino codice saltato" "Gray"
    Write-ColorOutput ""
}

# SETUP AMBIENTE
if (!$SkipSource) {
    Write-ColorOutput "⚙️ SETUP AMBIENTE..." "Yellow"
    
    try {
        # Navigare nella cartella ripristinata
        Push-Location $RestorePath
        
        # Ripristino pacchetti NuGet
        Write-ColorOutput "   📦 Ripristino pacchetti NuGet..." "Gray"
        dotnet restore --verbosity quiet
        
        if ($LASTEXITCODE -ne 0) {
            throw "Errore durante dotnet restore"
        }
        
        # Build progetto
        Write-ColorOutput "   🔨 Compilazione progetto..." "Gray"
        dotnet build --configuration Release --verbosity quiet
        
        if ($LASTEXITCODE -ne 0) {
            throw "Errore durante dotnet build"
        }
        
        Write-ColorOutput "✅ Ambiente configurato con successo" "Green"
        
        # Torna alla cartella originale
        Pop-Location
        
    } catch {
        Write-ColorOutput "❌ Errore setup ambiente: $_" "Red"
        Write-ColorOutput "   💡 Verifica che .NET 8.0 SDK sia installato" "Yellow"
        Pop-Location
    }
    Write-ColorOutput ""
}

# VERIFICA FINALE
Write-ColorOutput "🔍 VERIFICA FINALE..." "Yellow"

# Test connessione database
try {
    $dbTest = sqlcmd -S "IT15\SQLEXPRESS" -d "Consulting" -E -Q "SELECT 'OK' AS Status" -h -1 2>&1
    if ($dbTest.Trim() -eq "OK") {
        Write-ColorOutput "✅ Database: Connessione OK" "Green"
    } else {
        Write-ColorOutput "⚠️ Database: Connessione dubbio" "Yellow"
    }
} catch {
    Write-ColorOutput "❌ Database: Errore connessione" "Red"
}

# Test struttura codice
if (!$SkipSource -and (Test-Path "$RestorePath\Program.cs")) {
    Write-ColorOutput "✅ Codice: Struttura OK" "Green"
} else {
    Write-ColorOutput "⚠️ Codice: Struttura non verificata" "Yellow"
}

Write-ColorOutput ""

# RISULTATO FINALE
Write-ColorOutput "======================================================" "Cyan"
Write-ColorOutput "🎉 RIPRISTINO COMPLETATO!" "Green"
Write-ColorOutput "======================================================" "Cyan"
Write-ColorOutput ""
Write-ColorOutput "📍 INFORMAZIONI ACCESSO:" "Yellow"
Write-ColorOutput "   🌐 URL: http://localhost:5000" "White"
Write-ColorOutput "   👤 Username: admin" "White"
Write-ColorOutput "   🔑 Password: 123456" "White"
Write-ColorOutput ""
Write-ColorOutput "📁 PERCORSI:" "Yellow"
Write-ColorOutput "   💻 Codice: $RestorePath" "White"
Write-ColorOutput "   🗄️ Database: IT15\SQLEXPRESS\Consulting" "White"
Write-ColorOutput ""
Write-ColorOutput "🚀 PER AVVIARE L'APPLICAZIONE:" "Yellow"
Write-ColorOutput "   cd `"$RestorePath`"" "White"
Write-ColorOutput "   dotnet run --urls `"http://localhost:5000`"" "White"
Write-ColorOutput ""
Write-ColorOutput "📋 FUNZIONALITÀ DISPONIBILI:" "Yellow"
Write-ColorOutput "   🏦 8 Sezioni DatiUtenza complete" "White"
Write-ColorOutput "   🔐 Password sempre visibili" "White"
Write-ColorOutput "   👥 Sistema permessi granulari" "White"
Write-ColorOutput "   💾 Database con dati di test" "White"
Write-ColorOutput ""

# Opzione avvio automatico
$startApp = Read-Host "🚀 Vuoi avviare l'applicazione ora? (s/n)"
if ($startApp -eq "s" -or $startApp -eq "S" -or $startApp -eq "si") {
    Write-ColorOutput ""
    Write-ColorOutput "🚀 Avvio applicazione..." "Green"
    Set-Location $RestorePath
    Start-Process "http://localhost:5000"
    dotnet run --urls "http://localhost:5000"
}

Write-ColorOutput ""
Write-ColorOutput "✨ Ripristino terminato con successo!" "Green"